# First test problem
**description**

A+B Problem,输入两个整数A，B，输出两个数的和N

**demo in 1**

1 3

**demo out 1**

4

**data limit**

***A,B<N<1e9***
